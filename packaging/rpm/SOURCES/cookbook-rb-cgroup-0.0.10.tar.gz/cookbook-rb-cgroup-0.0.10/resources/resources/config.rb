unified_mode true

# Cookbook:: :: rbaioutliers
#
# Resource:: config
#

actions :add, :remove
default_action :add
