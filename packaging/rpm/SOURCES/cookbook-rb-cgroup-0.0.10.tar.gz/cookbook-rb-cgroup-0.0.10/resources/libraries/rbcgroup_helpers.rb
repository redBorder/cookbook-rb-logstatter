module Rbaioutliers
  module Helpers
  end
end
