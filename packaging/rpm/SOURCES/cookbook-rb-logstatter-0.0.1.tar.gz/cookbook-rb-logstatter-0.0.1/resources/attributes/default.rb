#default attributes
#

default["rb-logstatter"]["registered"] = false
