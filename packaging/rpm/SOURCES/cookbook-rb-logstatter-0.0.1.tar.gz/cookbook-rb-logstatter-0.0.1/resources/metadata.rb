name             'rblogstatter'
maintainer       'redborder'
maintainer_email 'malvarez@redborder.com'
license          'AGPL-3.0'
description      'Installs/Configures cookbook-rb-logstatter'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.0.1'
